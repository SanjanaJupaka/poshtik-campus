============================================================
POSHTIK CAMPUS - LAB 3 RESCUE PACK
UI23PC510CS/511CS - FSWD - Vasavi College of Engineering
============================================================

READ THIS WHOLE FILE BEFORE TOUCHING ANYTHING ELSE.

------------------------------------------------------------
1. WHO THIS PACK IS FOR - AND WHO IT IS NOT FOR
------------------------------------------------------------
This pack is an EMERGENCY BRIDGE, nothing more. It exists for
exactly three situations:

  (a) your machine died / was replaced and you have no backup;
  (b) you were genuinely absent for Labs 1-2 or Classes 9-12
      (with your instructor's knowledge);
  (c) your instructor explicitly told you to use it.

It is NOT for anyone who simply skipped the earlier labs.
Labs 1 and 2 are where you learned to WRITE this HTML - the
exams test that skill on paper, with no pack to rescue you.
Using this pack without genuine need does not save you work;
it only moves the work to the exam hall, where it costs marks.

TALK TO YOUR INSTRUCTOR BEFORE USING THIS PACK. No exceptions.

------------------------------------------------------------
2. STOP - THE BEST RESCUE IS NOT THIS PACK
------------------------------------------------------------
If you ever pushed your repo to GitHub (every lab since Lab 1
ends with a push), your real work is already safe. On any
machine:

    git clone https://github.com/<your-username>/poshtik-campus.git

That gives you YOUR pages, YOUR images and YOUR full commit
history - strictly better than anything in this folder.
Only continue below if you have no pushed repo to clone.

If your folder exists and only the @media block is missing,
you do not need this pack either: Class 12's Part 10 shows the
16-line block - type it in and you are current in five minutes.

------------------------------------------------------------
3. WHAT THIS PACK RESTORES - IN PLAIN WORDS
------------------------------------------------------------
Lab 3 starts exactly where LAB 2 LEFT OFF, plus the stylesheet
the classes grew in between:

  - Lab 1 built the three pages (index, menu, about).
  - Lab 2 grew menu.html: it gained the ORDER FORM.
    That was the last time a lab touched this folder.
  - Class 10 then created style.css (40 base lines) and
    Class 12 appended the @media block (lines 41-56).

This pack is that whole starting point, complete:

    index.html    - Lab 1's front door. NOTE: still un-semantic
                    (plain list nav, no header/footer tags).
                    That is CORRECT - its semantic surgery is
                    Lab 3's opening move. Do not "fix" it now.
    menu.html     - Lab 1's menu + LAB 2's ORDER FORM, semantic
                    skeleton from Class 8.
    about.html    - Lab 1's about page, semantic skeleton.
    style.css     - EXACTLY 56 lines: Class 10's 40 base lines
                    + Class 12's @media block (lines 41-56).
    images\       - the logo AND all ten dish photos:
                    jonna-rotte-wrap.png, sajja-roti-wrap.png,
                    ragi-sangati-bowl.png, ragi-idli-bowl.jpg,
                    pesarattu-with-sprouts.jpg,
                    ulava-charu-protein-bowl.jpg,
                    gongura-sprouts-salad.jpg,
                    sprouts-moong-chilla.jpg,
                    paneer-protein-bowl.jpg,
                    millet-protein-shake.jpg

Nothing else is needed. After setup you can follow every
minute of Lab 3 with the same files as everyone else.

------------------------------------------------------------
4. SETUP - TEN MINUTES, IN THIS EXACT ORDER
------------------------------------------------------------
 1. Create the folder:  C:\Users\<you>\Desktop\poshtik-campus\
 2. Copy index.html, menu.html, about.html, style.css and the
    whole images\ folder into it. The images\ folder stays a
    folder INSIDE poshtik-campus\ - do not loose-copy the
    photos next to the html files.
 3. Open style.css and COUNT: exactly 56 lines, @media last.
 4. Open all three pages in the browser - dark banner, mint
    dish cards, a photo beside every dish, styled nav on
    menu/about. Drag the window below 600px: cards go
    full-width. If not, re-check steps 2-3.
 5. Make it a repo - ONE honest commit, exactly this message:

        git init
        git add .
        git commit -m "Catch up to Lab 3 starting point (rescue pack)"

 6. Create an empty GitHub repo named poshtik-campus, link and
    push (Lab 1 Part 15 shows the three commands). From today
    YOUR pushed repo is your insurance - this pack retires.

------------------------------------------------------------
5. THE HONEST SCAR - READ THIS TWICE
------------------------------------------------------------
Your classmates' git log shows four earned commits:

    7a2b5f9 Add phone layout via first media query
    c3e6d10 Add site-wide stylesheet
    4f9c2b1 Add order form to menu      <- Lab 2's exit
    a1d3e07 First version of Poshtik Campus site

Yours shows ONE rescue commit instead. That is deliberate.
We do not fake history in this course - a repo's log is its
autobiography, and yours honestly says "I caught up here."
During Lab 3's Part 12 log-reading, your list will be shorter;
own that out loud. Your three Lab 3 commits will stack on top
of the rescue commit, and from Unit 2 onward your story is
earned line by line like everyone else's.

------------------------------------------------------------
6. THE DEBT - HOW TO ACTUALLY CATCH UP
------------------------------------------------------------
This pack restores FILES, not SKILLS. The skills live in the
sessions you missed, and every one is self-paced in Learning
Mode (scroll + sliders, no presenter needed):

    lab-01.html  - build pages like these from a blank file
    lab-02.html  - build the order form yourself (exam banker!)
    class-09.html / class-10.html - selectors + external CSS
    class-12.html - the @media block you just received

Work through them this week, in the fswd-practice sandbox -
nothing you do there can damage this repo. The four exam
papers reward exactly those hands; this pack rewards nothing.

Now open lab-03.html, run Part 1's starting-line check
(56 lines - yes, you pass), and build the rest yourself.
============================================================
